import sys
from datetime import datetime
from pathlib import Path
import pandas as pd
from torch.utils.data import Dataset
import numpy as np
import torch
from chemprop.data import get_data, get_task_names, MoleculeDataset, validate_dataset_type
from chemprop.data import get_class_sizes, get_data, MoleculeDataLoader, MoleculeDataset, set_cache_graph, split_data
from torch import nn, optim
from torch.utils.data import DataLoader
from tqdm.auto import tqdm
import os
from rdkit import Chem
import csv
from torch.utils.data import DataLoader, Dataset, Sampler
from chemprop.args import TrainArgs
from chemprop.utils import build_optimizer, build_lr_scheduler, get_loss_func, load_checkpoint, makedirs, \
    save_checkpoint, save_smiles_splits
from chemprop.models import MoleculeModel
import metrics
if __name__ == '__main__':
    SHOW_PROCESS_BAR = True
    best_code = 100000000000
    best_epoch = 0
    data_list = []
    start = datetime.now()
    data_path = '../data/'
    data_path = Path(data_path)
    max_seq_len = 1000
    max_smi_len = 150
    PT_FEATURE_SIZE = 40
    PT_FEATURE_SIZE_pkt = 63
    smile_list = []
    affinity_list = []

    args = TrainArgs()
    init_seed = args.seed
    args.data_path = '../data/training/'
    args.task_names = get_task_names(path=args.data_path, smiles_columns=args.smiles_columns,
                                         target_columns=args.target_columns, ignore_columns=args.ignore_columns)

    args.adjacency_path = '../data/training/'
    args.distance_path = '../data/training/'
    args.coulomb_path = '../data/training/'
    args.features_path = '../data/training/'
    args.dataset_type = 'regression'
    args.bond_attention = True
    args.atom_attention = True
    args.normalize_matrices =True

    train_data = get_data(
        path=args.data_path,
        graphs_data_path=graph_path,
        args=args,
        smiles_columns=args.smiles_columns,
        features_path='../data/training/',
        # logger=logger,
        skip_none_targets=True
    )
    data_loader = MoleculeDataLoader(
        dataset=train_data,
        batch_size=128,
        num_workers=args.num_workers,
        class_balance=args.class_balance,
        shuffle=True,
        seed=args.seed
        )

    args.dataset_type = 'regression'
    loss_func = get_loss_func(args)
    args.features_size = train_data.features_size()
    args.ffn_hidden_size = 900
    model = MoleculeModel(args)
    model = model.to(args.device)
    print(model)
    optimizer = build_optimizer(model, args)
    args.train_data_size = len(train_data)
    scheduler = build_lr_scheduler(optimizer, args)
    best_evaluation = {}
    Epoch = 600
    loss_sum_print = []
    for epoch in range(Epoch):
        loss_sum = iter_count = 0
        model.train()
        for batch in tqdm(data_loader, disable=not SHOW_PROCESS_BAR, total=len(data_loader), leave=False):
            print('train_epoch', epoch)
            batch: MoleculeDataset
            mol_batch, features_batch, target_batch, mol_adj_batch, mol_dist_batch, mol_clb_batch, mol_seq_batch, mol_sml_batch,mol_pocket_graph = \
                batch.batch_graph(), batch.features(), batch.targets(), batch.adj_features(), \
                    batch.dist_features(), batch.clb_features(), batch.seq(), batch.sml(),batch.pocket_graph

            mask = torch.Tensor([[x is not None for x in tb]
                                 for tb in target_batch])
            targets = torch.Tensor(
                [[0 if x is None else x for x in tb] for tb in target_batch])
            model.zero_grad()
            preds = model(mol_batch, features_batch, mol_adj_batch,
                          mol_dist_batch, mol_clb_batch, mol_seq_batch, mol_sml_batch,mol_pocket_graph)
            mask = mask.to(preds.device)
            targets = targets.to(preds.device)
            class_weights = torch.ones(targets.shape, device=preds.device)
            loss = loss_func(preds, targets) * class_weights * mask
            loss = loss.sum() / mask.sum()
            loss_sum += loss.item()
            loss_self = loss_func(preds, targets)
            loss = torch.sum(loss_self)
            print('train_loss', loss)
            loss.backward()
            optimizer.step()
            scheduler.step()
            targets_cpu = targets.detach().cpu().numpy()
            preds_cpu = preds.detach().cpu().numpy()
            targets_cpu = np.concatenate(targets_cpu).reshape(
                -1)
            preds_cpu = np.concatenate(preds_cpu).reshape(-1)





result_df = pd.DataFrame()
for data_dict in data_list:
    df = pd.DataFrame.from_dict(data_dict, orient='index').T.set_index('c_index')
    result_df = result_df.append(df)

end = datetime.now()

