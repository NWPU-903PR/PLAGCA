# -- coding: utf-8 --
from __future__ import annotations

import threading
from collections import OrderedDict
from random import Random
from typing import Dict, Iterator, List, Optional, Union, Tuple, Any

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset, Sampler
from rdkit import Chem

from .scaler import StandardScaler
from chemprop.features import BatchMolGraph, MolGraph, get_atom_fdim, get_bond_fdim
from chemprop.features import load_features
import csv

try:
    import networkx as nx
except Exception:
    nx = None


CACHE_GRAPH = False
SMILES_TO_GRAPH: Dict[str, MolGraph] = {}

def cache_graph() -> bool:
    return CACHE_GRAPH

def set_cache_graph(cache_graph_: bool) -> None:
    global CACHE_GRAPH
    CACHE_GRAPH = cache_graph_

CACHE_MOL = True
SMILES_TO_MOL: Dict[str, Chem.Mol] = {}

def cache_mol() -> bool:
    return CACHE_MOL

def set_cache_mol(cache_mol_: bool) -> None:
    global CACHE_MOL
    CACHE_MOL = cache_mol_


class MoleculeDatapoint:


    def __init__(self,
                 smiles: List[str],
                 sequences: Optional[List[Any]] = None,
                 targets: Optional[List[Optional[float]]] = None,
                 row: Optional[OrderedDict] = None,
                 features: Optional[np.ndarray] = None,
                 features_generator: Optional[List[str]] = None,
                 mol_adj: Optional[np.ndarray] = None,
                 mol_dist: Optional[np.ndarray] = None,
                 mol_clb: Optional[np.ndarray] = None,
                 SMILES: Optional[np.ndarray] = None,
                 mol_seq: Optional[List[Any]] = None,
                 pocket: Optional[Any] = None):
        if features is not None and features_generator is not None:
            raise ValueError('Cannot provide both loaded features and a features generator.')

        self.smiles = smiles
        self.targets = targets
        self.sequences = sequences
        self.SMILES = SMILES
        self.row = row

        self.features = features
        self.features_generator = features_generator

        self.mol_adj = mol_adj
        self.mol_dist = mol_dist
        self.mol_clb = mol_clb

        self.mol_seq = mol_seq

        self.pocket = pocket

        replace_token = 0
        if self.features is not None:
            self.features = np.where(np.isnan(self.features), replace_token, self.features)
            self.features = np.where(np.isinf(self.features), replace_token, self.features)


        for name in ('mol_adj', 'mol_dist', 'mol_clb'):
            arr = getattr(self, name)
            if arr is not None:
                arr = np.where(np.isnan(arr), replace_token, arr)
                arr = np.where(np.isinf(arr), replace_token, arr)
                setattr(self, name, arr)

        self.raw_features, self.raw_targets = self.features, self.targets
        self.raw_mol_adj, self.raw_mol_dist, self.raw_mol_clb = self.mol_adj, self.mol_dist, self.mol_clb

    @property
    def mol(self) -> List[Chem.Mol]:
        mols = [SMILES_TO_MOL.get(s, Chem.MolFromSmiles(s)) for s in self.smiles]
        if cache_mol():
            for s, m in zip(self.smiles, mols):
                SMILES_TO_MOL[s] = m
        return mols

    @property
    def number_of_molecules(self) -> int:
        return len(self.smiles)

    def set_features(self, features: np.ndarray) -> None:
        self.features = features

    def set_mol_adj(self, mol_adj: np.ndarray) -> None:
        self.mol_adj = mol_adj

    def set_mol_dist(self, mol_dist: np.ndarray) -> None:
        self.mol_dist = mol_dist

    def set_mol_clb(self, mol_clb: np.ndarray) -> None:
        self.mol_clb = mol_clb

    def set_mol_seq(self, seq: List[Any]) -> None:
        self.mol_seq = seq

    def set_pocket(self, pkt: Any) -> None:
        self.pocket = pkt

    def extend_features(self, features: np.ndarray) -> None:
        self.features = np.append(self.features, features) if self.features is not None else features

    def num_tasks(self) -> int:
        return len(self.targets) if self.targets is not None else 0

    def set_targets(self, targets: List[Optional[float]]):
        self.targets = targets

    def reset_features_and_targets(self) -> None:
        self.features, self.targets = self.raw_features, self.raw_targets
        self.mol_adj, self.mol_dist, self.mol_clb = self.raw_mol_adj, self.raw_mol_dist, self.raw_mol_clb


class MoleculeDataset(Dataset):
    def __init__(self, data: List[MoleculeDatapoint]):
        self._data = data
        self._scaler: Optional[StandardScaler] = None
        self._batch_graph: Optional[List[BatchMolGraph]] = None
        self._random = Random()

    def smiles(self, flatten: bool = False) -> Union[List[str], List[List[str]]]:
        return [s for d in self._data for s in d.smiles] if flatten else [d.smiles for d in self._data]

    def sequences(self, flatten: bool = False) -> Union[List[Any], List[List[Any]]]:
        return [s for d in self._data for s in d.sequences] if flatten else [d.sequences for d in self._data]

    def mols(self, flatten: bool = False) -> Union[List[Chem.Mol], List[List[Chem.Mol]]]:
        return [m for d in self._data for m in d.mol] if flatten else [d.mol for d in self._data]

    @property
    def number_of_molecules(self) -> int:
        return self._data[0].number_of_molecules if len(self._data) > 0 else None

    def batch_graph(self) -> List[BatchMolGraph]:
        if self._batch_graph is None:
            mol_graphs_all: List[List[MolGraph]] = []
            for d in self._data:
                graphs_one: List[MolGraph] = []
                for s, m in zip(d.smiles, d.mol):
                    if s in SMILES_TO_GRAPH:
                        mol_graph = SMILES_TO_GRAPH[s]
                    else:
                        mol_graph = MolGraph(m, d.mol_adj, d.mol_dist, d.mol_clb)
                        if cache_graph():
                            SMILES_TO_GRAPH[s] = mol_graph
                    graphs_one.append(mol_graph)
                mol_graphs_all.append(graphs_one)
            self._batch_graph = [BatchMolGraph([g[i] for g in mol_graphs_all])
                                 for i in range(len(mol_graphs_all[0]))]
        return self._batch_graph

    def features(self) -> Optional[List[np.ndarray]]:
        if len(self._data) == 0 or self._data[0].features is None:
            return None
        return [d.features for d in self._data]

    def adj_features(self) -> Optional[List[np.ndarray]]:
        if len(self._data) == 0 or self._data[0].mol_adj is None:
            return None
        return [d.mol_adj for d in self._data]

    def dist_features(self) -> Optional[List[np.ndarray]]:
        if len(self._data) == 0 or self._data[0].mol_dist is None:
            return None
        return [d.mol_dist for d in self._data]

    def clb_features(self) -> Optional[List[np.ndarray]]:
        if len(self._data) == 0 or self._data[0].mol_clb is None:
            return None
        return [d.mol_clb for d in self._data]

    def targets(self) -> List[List[Optional[float]]]:
        return [d.targets for d in self._data]

    def seq(self) -> List[List[Any]]:
        return [d.sequences for d in self._data]

    def sml(self) -> List[List[Any]]:
        return [d.SMILES for d in self._data]

    def pkt(self) -> Optional[List[Any]]:
        if len(self._data) == 0 or getattr(self._data[0], "pocket", None) is None:
            return None
        return [d.pocket for d in self._data]

    def num_tasks(self) -> int:
        return self._data[0].num_tasks() if len(self._data) > 0 else None

    def features_size(self) -> Optional[int]:
        return len(self._data[0].features) if (len(self._data) > 0 and self._data[0].features is not None) else None

    def normalize_features(self, scaler: StandardScaler = None, replace_nan_token: int = 0,
                           scale_atom_descriptors: bool = False, scale_bond_features: bool = False) -> Optional[StandardScaler]:
        if len(self._data) == 0 or self._data[0].features is None:
            return None
        if scaler is not None:
            self._scaler = scaler
        elif self._scaler is None:
            features = np.vstack([d.raw_features for d in self._data])
            self._scaler = StandardScaler(replace_nan_token=replace_nan_token)
            self._scaler.fit(features)

        for d in self._data:
            d.set_features(self._scaler.transform(d.raw_features.reshape(1, -1))[0])
        return self._scaler

    def normalize_targets(self) -> StandardScaler:
        targets = [d.raw_targets for d in self._data]
        scaler = StandardScaler().fit(targets)
        scaled_targets = scaler.transform(targets).tolist()
        self.set_targets(scaled_targets)
        return scaler

    def set_targets(self, targets: List[List[Optional[float]]]) -> None:
        assert len(self._data) == len(targets)
        for i in range(len(self._data)):
            self._data[i].set_targets(targets[i])

    def reset_features_and_targets(self) -> None:
        for d in self._data:
            d.reset_features_and_targets()

    def __len__(self) -> int:
        return len(self._data)

    def __getitem__(self, item) -> Union[MoleculeDatapoint, List[MoleculeDatapoint]]:
        return self._data[item]



class MoleculeSampler(Sampler):
    def __init__(self,
                 dataset: MoleculeDataset,
                 class_balance: bool = False,
                 shuffle: bool = False,
                 seed: int = 0):
        super(Sampler, self).__init__()
        self.dataset = dataset
        self.class_balance = class_balance
        self.shuffle = shuffle
        self._random = Random(seed)

        if self.class_balance:
            indices = np.arange(len(dataset))
            has_active = np.array([any(target == 1 for target in datapoint.targets) for datapoint in dataset])
            self.positive_indices = indices[has_active].tolist()
            self.negative_indices = indices[~has_active].tolist()
            self.length = 2 * min(len(self.positive_indices), len(self.negative_indices))
        else:
            self.positive_indices = self.negative_indices = None
            self.length = len(self.dataset)

    def __iter__(self) -> Iterator[int]:
        if self.class_balance:
            if self.shuffle:
                self._random.shuffle(self.positive_indices)
                self._random.shuffle(self.negative_indices)
            indices = [index for pair in zip(self.positive_indices, self.negative_indices) for index in pair]
        else:
            indices = list(range(len(self.dataset)))
            if self.shuffle:
                self._random.shuffle(indices)
        return iter(indices)

    def __len__(self) -> int:
        return self.length


def construct_molecule_batch(data: List[MoleculeDatapoint]) -> MoleculeDataset:
    data = MoleculeDataset(data)
    data.batch_graph()
    return data


class MoleculeDataLoader(DataLoader):
    def __init__(self,
                 dataset: MoleculeDataset,
                 batch_size: int = 50,
                 num_workers: int = 0,
                 class_balance: bool = False,
                 shuffle: bool = False,
                 seed: int = 0):
        self._dataset = dataset
        self._batch_size = batch_size
        self._num_workers = num_workers
        self._class_balance = class_balance
        self._shuffle = shuffle
        self._seed = seed
        self._context = None
        self._timeout = 0

        is_main_thread = threading.current_thread() is threading.main_thread()
        if not is_main_thread and self._num_workers > 0:
            self._context = 'forkserver'
            self._timeout = 3600

        self._sampler = MoleculeSampler(dataset=self._dataset,
                                        class_balance=self._class_balance,
                                        shuffle=self._shuffle,
                                        seed=self._seed)

        super(MoleculeDataLoader, self).__init__(
            dataset=self._dataset,
            batch_size=self._batch_size,
            sampler=self._sampler,
            num_workers=self._num_workers,
            collate_fn=construct_molecule_batch,
            multiprocessing_context=self._context,
            timeout=self._timeout
        )

    @property
    def targets(self) -> List[List[Optional[float]]]:
        if self._class_balance or self._shuffle:
            raise ValueError('Cannot safely extract targets when class balance or shuffle are enabled.')
        return [self._dataset[index].targets for index in self._sampler]

    @property
    def iter_size(self) -> int:
        return len(self._sampler)

    def __iter__(self) -> Iterator[MoleculeDataset]:
        return super(MoleculeDataLoader, self).__iter__()


def _maybe_encode_sequence(raw_seq_list: List[str]) -> List[Any]:

    try:
        encoded = encode_and_adjust_length(raw_seq_list, targetSeq_vocab)  # type: ignore
        return encoded
    except Exception:
        return raw_seq_list

def _maybe_encode_smiles(raw_smi_list: List[str]) -> List[Any]:

    try:
        encoded = encodesmile_and_adjust_length(raw_smi_list, smiles_vocab)
        return encoded
    except Exception:
        return raw_smi_list

def _extract_graph_from_bin_item(item: Any) -> Any:

    if nx is not None and isinstance(item, nx.Graph):
        return item
    if isinstance(item, dict):
        if 'graph' in item:
            return item['graph']
        if 'entries' in item and item['entries']:
            entry0 = item['entries'][0]
            if isinstance(entry0, dict) and 'graph' in entry0:
                return entry0['graph']
    return item

def get_data(path: str,
             smiles_columns: Union[str, List[str]] = None,
             target_columns: List[str] = None,
             ignore_columns: List[str] = None,
             skip_invalid_smiles: bool = True,
             args: Any = None,
             features_path: Union[str, List[str], None] = None,
             features_generator: List[str] = None,
             adjacency_path: str = None,
             distance_path: str = None,
             coulomb_path: str = None,
             pocket_bin: Optional[str] = None,
             max_data_size: int = None,
             store_row: bool = False,
             logger: Any = None,
             skip_none_targets: bool = False) -> MoleculeDataset:

    debug = logger.debug if logger is not None else print

    if args is not None:
        smiles_columns = smiles_columns if smiles_columns is not None else args.smiles_columns
        target_columns = target_columns if target_columns is not None else args.target_columns
        ignore_columns = ignore_columns if ignore_columns is not None else args.ignore_columns
        features_generator = features_generator if features_generator is not None else args.features_generator
        adjacency_path = adjacency_path if adjacency_path is not None else getattr(args, "adjacency_path", None)
        distance_path = distance_path if distance_path is not None else getattr(args, "distance_path", None)
        coulomb_path = coulomb_path if coulomb_path is not None else getattr(args, "coulomb_path", None)
        pocket_bin = pocket_bin if pocket_bin is not None else getattr(args, "pocket_bin", None)
        max_data_size = max_data_size if max_data_size is not None else args.max_data_size


    if not isinstance(smiles_columns, list):
        smiles_columns = [smiles_columns] if smiles_columns is not None else ['smiles']

    max_data_size = max_data_size or float('inf')


    if features_path is not None:
        if isinstance(features_path, list):
            feats_list = [load_features(fp) for fp in features_path]
            features_data = np.concatenate(feats_list, axis=1)
        else:
            features_data = load_features(features_path)
    else:
        features_data = None

    adj_features_data = np.load(adjacency_path, allow_pickle=True)['features'] if adjacency_path else None
    dist_features_data = np.load(distance_path, allow_pickle=True)['features'] if distance_path else None
    clb_features_data = np.load(coulomb_path, allow_pickle=True)['features'] if coulomb_path else None

    pocket_list: Optional[List[Any]] = None
    if pocket_bin is not None:
        pocket_raw = torch.load(pocket_bin, map_location='cpu')
        pocket_list = []
        for item in pocket_raw:
            pocket_list.append(_extract_graph_from_bin_item(item))

    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)

        target_name = 'affinity'
        seq_col = 'sequence'

        all_smiles: List[List[str]] = []
        all_targets: List[List[Optional[float]]] = []
        all_sequences: List[List[Any]] = []
        all_SMILES: List[List[Any]] = []
        all_rows = []
        all_features = []
        all_adj_features = []
        all_dist_features = []
        all_clb_features = []
        all_pockets = []

        for i, row in enumerate(reader):
            smiles = [row[c] for c in smiles_columns]
            try:
                targets = [float(row[target_name])]
            except Exception:
                targets = [None]

            seq_raw = [row[seq_col]] if seq_col in row else [""]
            sequences = _maybe_encode_sequence(seq_raw)
            smiles_enc = _maybe_encode_smiles(smiles)

            all_smiles.append(smiles)
            all_targets.append(targets)
            all_sequences.append(sequences)
            all_SMILES.append(smiles_enc)

            if features_data is not None:
                all_features.append(features_data[i])

            if adj_features_data is not None:
                all_adj_features.append(adj_features_data[i])
            if dist_features_data is not None:
                all_dist_features.append(dist_features_data[i])
            if clb_features_data is not None:
                all_clb_features.append(clb_features_data[i])

            if pocket_list is not None:
                all_pockets.append(pocket_list[i])

            if store_row:
                all_rows.append(row)

            if len(all_smiles) >= max_data_size:
                break

    data_points: List[MoleculeDatapoint] = []
    n = len(all_smiles)
    for i in range(n):
        dp = MoleculeDatapoint(
            smiles=all_smiles[i],
            sequences=all_sequences[i],
            targets=all_targets[i],
            row=all_rows[i] if store_row else None,
            features=(all_features[i] if features_data is not None else None),
            mol_adj=(all_adj_features[i] if adj_features_data is not None else None),
            mol_dist=(all_dist_features[i] if dist_features_data is not None else None),
            mol_clb=(all_clb_features[i] if clb_features_data is not None else None),
            SMILES=all_SMILES[i],
            pocket=(all_pockets[i] if pocket_list is not None else None)
        )
        data_points.append(dp)

    return MoleculeDataset(data_points)
