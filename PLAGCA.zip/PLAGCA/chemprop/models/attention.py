import torch
import torch.nn as nn
import torch.nn.functional as F
import einops

from chemprop.args import TrainArgs
from chemprop.nn_utils import get_activation_function


class MultiBondFastAttention(nn.Module):
    """
    A :class:`MultiBondFastAttention` is the bond level self-attention block (Fastformer) in the message passing phase.
    """

    def __init__(self, args: TrainArgs):
        super(MultiBondFastAttention, self).__init__()
        self.hidden_size = args.hidden_size
        self.bias = args.bias
        self.dropout = args.dropout
        self.cached_zero_vector = nn.Parameter(
            torch.zeros(self.hidden_size), requires_grad=False)
        self.dropout_layer = nn.Dropout(p=self.dropout)
        self.act_func = get_activation_function(args.activation)

        self.num_heads = args.num_heads
        self.att_size = self.hidden_size // self.num_heads
        self.scale_factor = self.att_size ** -0.5
        self.weight_alpha = nn.Parameter(torch.randn(self.att_size))
        self.weight_beta = nn.Parameter(torch.randn(self.att_size))
        self.weight_r = nn.Linear(self.att_size, self.att_size, bias=False)

        self.W_b_q = nn.Linear(self.hidden_size, self.num_heads * self.att_size, bias=False)
        self.W_b_k = nn.Linear(self.hidden_size, self.num_heads * self.att_size, bias=False)
        self.W_b_v = nn.Linear(self.hidden_size, self.num_heads * self.att_size, bias=False)
        self.W_b_o = nn.Linear(self.num_heads * self.att_size, self.hidden_size)
        self.norm = nn.LayerNorm(self.hidden_size, elementwise_affine=True)

    def forward(self, message, b_scope):
        bond_vecs = []
        for i, (b_start, b_size) in enumerate(b_scope):
            if i == 0:
                bond_vecs.append(self.cached_zero_vector)
            cur_bond_message = message.narrow(0, b_start, b_size)
            cur_bond_message_size = cur_bond_message.size()

            b_q = self.W_b_q(cur_bond_message).view(cur_bond_message_size[0], self.num_heads, self.att_size)
            b_k = self.W_b_k(cur_bond_message).view(cur_bond_message_size[0], self.num_heads, self.att_size)
            b_v = self.W_b_v(cur_bond_message).view(cur_bond_message_size[0], self.num_heads, self.att_size)
            b_q = b_q.transpose(0, 1)
            b_k = b_k.transpose(0, 1)
            b_v = b_v.transpose(0, 1)
            h, n, d = b_q.shape

            alpha_weight = torch.mul(b_q, self.weight_alpha) * self.scale_factor
            alpha_weight = F.softmax(alpha_weight, dim=-1)
            global_query = torch.mul(alpha_weight, b_q)
            global_query = torch.sum(global_query, dim=1)

            repeat_global_query = einops.repeat(global_query, 'h d -> h copy d', copy=n)
            p = torch.mul(repeat_global_query, b_k)
            beta_weight = torch.mul(p, self.weight_beta) * self.scale_factor
            beta_weight = F.softmax(beta_weight, dim=-1)
            global_key = torch.mul(beta_weight, p)
            global_key = torch.sum(global_key, dim=1)

            key_value_interaction = torch.einsum('hd,hnd->hnd', global_key, b_v)
            key_value_interaction_out = self.weight_r(key_value_interaction)
            att_b_h = key_value_interaction_out + b_q

            att_b_h = self.act_func(att_b_h)
            att_b_h = self.dropout_layer(att_b_h)
            att_b_h = att_b_h.transpose(0, 1).contiguous()
            att_b_h = att_b_h.view(cur_bond_message_size[0], self.num_heads * self.att_size)
            att_b_h = self.W_b_o(att_b_h)
            assert att_b_h.size() == cur_bond_message_size

            att_b_h = att_b_h.unsqueeze(dim=0)
            att_b_h = self.norm(att_b_h)
            att_b_h = (att_b_h).squeeze(dim=0)

            bond_vecs.extend(att_b_h)

        bond_vecs = torch.stack(bond_vecs, dim=0)
        return bond_vecs


class MultiBondAttention(nn.Module):
    """
    A :class:`MultiBondAttention` is the bond level self-attention block (Transformer) in the message passing phase.
    """

    def __init__(self, args: TrainArgs):
        super(MultiBondAttention, self).__init__()
        self.hidden_size = args.hidden_size
        self.bias = args.bias
        self.dropout = args.dropout
        self.cached_zero_vector = nn.Parameter(torch.zeros(self.hidden_size), requires_grad=False)
        self.dropout_layer = nn.Dropout(p=self.dropout)
        self.act_func = get_activation_function(args.activation)
        self.num_heads = args.num_heads
        self.att_size = self.hidden_size // self.num_heads
        self.scale_factor = self.att_size ** -0.5

        self.W_b_q = nn.Linear(self.hidden_size, self.num_heads * self.att_size, bias=False)
        self.W_b_k = nn.Linear(self.hidden_size, self.num_heads * self.att_size, bias=False)
        self.W_b_v = nn.Linear(self.hidden_size, self.num_heads * self.att_size, bias=False)
        self.W_b_o = nn.Linear(self.num_heads * self.att_size, self.hidden_size)
        self.norm = nn.LayerNorm(self.hidden_size, elementwise_affine=True)

    def forward(self, message, b_scope):
        bond_vecs = []
        for i, (b_start, b_size) in enumerate(b_scope):
            if i == 0:
                bond_vecs.append(self.cached_zero_vector)

            cur_bond_message = message.narrow(0, b_start, b_size)
            cur_bond_message_size = cur_bond_message.size()

            b_q = self.W_b_q(cur_bond_message).view(cur_bond_message_size[0], self.num_heads, self.att_size)
            b_k = self.W_b_k(cur_bond_message).view(cur_bond_message_size[0], self.num_heads, self.att_size)
            b_v = self.W_b_v(cur_bond_message).view(cur_bond_message_size[0], self.num_heads, self.att_size)
            b_q = b_q.transpose(0, 1)
            b_k = b_k.transpose(0, 1).transpose(1, 2)
            b_v = b_v.transpose(0, 1)

            att_b_w = torch.matmul(b_q, b_k)
            att_b_w = F.softmax(att_b_w * self.scale_factor, dim=2)
            att_b_h = torch.matmul(att_b_w, b_v)
            att_b_h = self.act_func(att_b_h)
            att_b_h = self.dropout_layer(att_b_h)

            att_b_h = att_b_h.transpose(0, 1).contiguous()
            att_b_h = att_b_h.view(cur_bond_message_size[0], self.num_heads * self.att_size)
            att_b_h = self.W_b_o(att_b_h)
            assert att_b_h.size() == cur_bond_message_size

            att_b_h = att_b_h.unsqueeze(dim=0)
            att_b_h = self.norm(att_b_h)
            att_b_h = (att_b_h).squeeze(dim=0)

            bond_vecs.extend(att_b_h)

        bond_vecs = torch.stack(bond_vecs, dim=0)
        return bond_vecs


class MultiAtomAttention(nn.Module):
    """
    Atom-level self-attention in readout.
    """

    def __init__(self, args: TrainArgs):
        super(MultiAtomAttention, self).__init__()
        self.atom_attention = args.atom_attention
        self.hidden_size = args.hidden_size
        self.bias = args.bias
        self.dropout = args.dropout
        self.cached_zero_vector = nn.Parameter(torch.zeros(self.hidden_size), requires_grad=False)
        self.dropout_layer = nn.Dropout(p=self.dropout)
        self.act_func = get_activation_function(args.activation)
        self.normalize_matrices = args.normalize_matrices
        self.distance = True
        self.adjacency = True
        self.coulomb = True
        self.device = args.device
        self.num_heads = args.num_heads
        self.att_size = self.hidden_size // self.num_heads
        self.scale_factor = self.att_size ** -0.5
        self.f_scale = args.f_scale

        self.W_a_q = nn.Linear(self.hidden_size, self.num_heads * self.att_size, bias=False)
        self.W_a_k = nn.Linear(self.hidden_size, self.num_heads * self.att_size, bias=False)
        self.W_a_v = nn.Linear(self.hidden_size, self.num_heads * self.att_size, bias=False)
        self.W_a_o = nn.Linear(self.num_heads * self.att_size, self.hidden_size)
        self.norm = nn.LayerNorm(self.hidden_size, elementwise_affine=True)

    def forward(self, cur_hiddens, i, f_adj, f_dist, f_clb, viz_dir=None):
        cur_hiddens_size = cur_hiddens.size()

        a_q = self.W_a_q(cur_hiddens).view(cur_hiddens_size[0], self.num_heads, self.att_size)
        a_k = self.W_a_k(cur_hiddens).view(cur_hiddens_size[0], self.num_heads, self.att_size)
        a_v = self.W_a_v(cur_hiddens).view(cur_hiddens_size[0], self.num_heads, self.att_size)
        a_q = a_q.transpose(0, 1)
        a_k = a_k.transpose(0, 1).transpose(1, 2)
        a_v = a_v.transpose(0, 1)

        att_a_w = torch.matmul(a_q, a_k)

        if self.adjacency:
            mol_adj = torch.Tensor(f_adj[i]).to(self.device)
            att_a_w[0] = att_a_w[0] + self.f_scale * mol_adj
            att_a_w[1] = att_a_w[1] + self.f_scale * mol_adj

        if self.distance:
            mol_dist = torch.Tensor(f_dist[i]).to(self.device)
            if self.normalize_matrices:
                mol_dist = F.softmax(mol_dist, dim=1)
            att_a_w[2] = att_a_w[2] + self.f_scale * mol_dist
            att_a_w[3] = att_a_w[3] + self.f_scale * mol_dist

        if self.coulomb:
            mol_clb = torch.Tensor(f_clb[i]).to(self.device)
            if self.normalize_matrices:
                mol_clb = F.softmax(mol_clb, dim=1)
            att_a_w[4] = att_a_w[4] + self.f_scale * mol_clb
            att_a_w[5] = att_a_w[5] + self.f_scale * mol_clb

        att_a_w = F.softmax(att_a_w * self.scale_factor, dim=2)
        att_a_h = torch.matmul(att_a_w, a_v)
        att_a_h = self.act_func(att_a_h)
        att_a_h = self.dropout_layer(att_a_h)

        att_a_h = att_a_h.transpose(0, 1).contiguous()
        att_a_h = att_a_h.view(cur_hiddens_size[0], self.num_heads * self.att_size)
        att_a_h = self.W_a_o(att_a_h)
        assert att_a_h.size() == cur_hiddens_size

        att_a_h = att_a_h.unsqueeze(dim=0)
        att_a_h = self.norm(att_a_h)

        mol_vec = (att_a_h).squeeze(dim=0)
        return mol_vec, torch.mean(att_a_w, axis=0)


class MultiPocketAttention(nn.Module):

    def __init__(self, args: TrainArgs):
        super(MultiPocketAttention, self).__init__()
        self.atom_attention = args.atom_attention
        self.hidden_size = args.hidden_size
        self.bias = args.bias
        self.dropout = args.dropout
        self.cached_zero_vector = nn.Parameter(torch.zeros(self.hidden_size), requires_grad=False)
        self.dropout_layer = nn.Dropout(p=self.dropout)
        self.act_func = get_activation_function(args.activation)
        self.normalize_matrices = args.normalize_matrices
        self.device = args.device
        self.num_heads = args.num_heads
        self.att_size = self.hidden_size // self.num_heads
        self.scale_factor = self.att_size ** -0.5
        self.f_scale = args.f_scale

        #
        self.W_a_q = nn.Linear(self.hidden_size, self.num_heads * self.att_size, bias=False)
        self.W_a_k = nn.Linear(self.hidden_size, self.num_heads * self.att_size, bias=False)
        self.W_a_v = nn.Linear(self.hidden_size, self.num_heads * self.att_size, bias=False)
        self.W_a_o = nn.Linear(self.num_heads * self.att_size, self.hidden_size)
        self.norm = nn.LayerNorm(self.hidden_size, elementwise_affine=True)

        # NEW
        self.W_p_k = nn.Linear(self.hidden_size, self.num_heads * self.att_size, bias=False)
        self.W_p_v = nn.Linear(self.hidden_size, self.num_heads * self.att_size, bias=False)

    def _is_cross_pkt(self, pkt_item):
        return isinstance(pkt_item, dict) and ('emb' in pkt_item)

    def forward(self, cur_hiddens, i, f_adj, f_dist, f_clb, f_pkt, flag, viz_dir=None):

        # ---
        if f_pkt is not None and self._is_cross_pkt(f_pkt[i]):
            pkt = f_pkt[i]
            p_emb = torch.as_tensor(pkt['emb'], device=self.device, dtype=cur_hiddens.dtype)  # (P, H)
            aff_bias = None
            if 'aff' in pkt and pkt['aff'] is not None:
                aff_bias = torch.as_tensor(pkt['aff'], device=self.device, dtype=cur_hiddens.dtype)  # (N, P)

            N = cur_hiddens.size(0)
            P = p_emb.size(0)

            a_q = self.W_a_q(cur_hiddens).view(N, self.num_heads, self.att_size).transpose(0, 1)
            p_k = self.W_p_k(p_emb).view(P, self.num_heads, self.att_size).transpose(0, 1).transpose(1, 2)
            p_v = self.W_p_v(p_emb).view(P, self.num_heads, self.att_size).transpose(0, 1)

            att = torch.matmul(a_q, p_k)  # (H, N, P)
            att = att * self.scale_factor
            if aff_bias is not None:

                att = att + aff_bias.unsqueeze(0)

            att = F.softmax(att, dim=2)
            out = torch.matmul(att, p_v)
            out = self.act_func(out)
            out = self.dropout_layer(out)

            out = out.transpose(0, 1).contiguous()
            out = out.view(N, self.num_heads * self.att_size)
            out = self.W_a_o(out)
            out = out.unsqueeze(0)
            out = self.norm(out)
            mol_vec = out.squeeze(0)
            att_mean = torch.mean(att, dim=0)
            return mol_vec, att_mean


        if flag == 0:
            cur_hiddens_size = cur_hiddens.size()

            a_q = self.W_a_q(cur_hiddens).view(cur_hiddens_size[0], self.num_heads, self.att_size)
            a_k = self.W_a_k(cur_hiddens).view(cur_hiddens_size[0], self.num_heads, self.att_size)
            a_v = self.W_a_v(cur_hiddens).view(cur_hiddens_size[0], self.num_heads, self.att_size)
            a_q = a_q.transpose(0, 1)
            a_k = a_k.transpose(0, 1).transpose(1, 2)
            a_v = a_v.transpose(0, 1)

            att_a_w = torch.matmul(a_q, a_k)  # (H, N, N)


            if f_adj is not None:
                mol_adj = torch.Tensor(f_adj[i]).to(self.device)
                att_a_w[0] = att_a_w[0] + self.f_scale * mol_adj
                att_a_w[1] = att_a_w[1] + self.f_scale * mol_adj

            if f_dist is not None:
                mol_dist = torch.Tensor(f_dist[i]).to(self.device)
                if self.normalize_matrices:
                    mol_dist = F.softmax(mol_dist, dim=1)
                att_a_w[2] = att_a_w[2] + self.f_scale * mol_dist
                att_a_w[3] = att_a_w[3] + self.f_scale * mol_dist

            if f_clb is not None:
                mol_clb = torch.Tensor(f_clb[i]).to(self.device)
                if self.normalize_matrices:
                    mol_clb = F.softmax(mol_clb, dim=1)
                att_a_w[4] = att_a_w[4] + self.f_scale * mol_clb
                att_a_w[5] = att_a_w[5] + self.f_scale * mol_clb

            # NEW
            if f_pkt is not None:
                pkt_mat = torch.as_tensor(f_pkt[i], device=self.device, dtype=att_a_w.dtype)
                if pkt_mat.dim() == 2 and pkt_mat.size(0) == pkt_mat.size(1) == att_a_w.size(-1):
                    h6 = min(6, self.num_heads - 1)
                    h7 = min(7, self.num_heads - 1)
                    att_a_w[h6] = att_a_w[h6] + self.f_scale * pkt_mat
                    att_a_w[h7] = att_a_w[h7] + self.f_scale * pkt_mat

            att_a_w = F.softmax(att_a_w * self.scale_factor, dim=2)
            att_a_h = torch.matmul(att_a_w, a_v)
            att_a_h = self.act_func(att_a_h)
            att_a_h = self.dropout_layer(att_a_h)

            att_a_h = att_a_h.transpose(0, 1).contiguous()
            att_a_h = att_a_h.view(cur_hiddens_size[0], self.num_heads * self.att_size)
            att_a_h = self.W_a_o(att_a_h)
            assert att_a_h.size() == cur_hiddens_size

            att_a_h = att_a_h.unsqueeze(0)
            att_a_h = self.norm(att_a_h)
            mol_vec = att_a_h.squeeze(0)

            return mol_vec, torch.mean(att_a_w, axis=0)


class SublayerConnection(nn.Module):
    """
    A residual connection followed by a layer norm.
    """
    def __init__(self, dropout):
        super(SublayerConnection, self).__init__()
        self.dropout = nn.Dropout(dropout)

    def forward(self, original, attention):
        return original + self.dropout(attention)
