# -- coding: utf-8 --
from __future__ import annotations
from typing import List, Union, Tuple, Optional, Any

import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from functools import reduce
from rdkit import Chem

from chemprop.args import TrainArgs
from chemprop.features import BatchMolGraph, get_atom_fdim, get_bond_fdim
from chemprop.nn_utils import index_select_ND, get_activation_function

try:
    import networkx as nx
except Exception:
    nx = None


def pad_and_mask(tensors: List[torch.Tensor], pad_dim: int = 0) -> Tuple[torch.Tensor, torch.Tensor]:

    if len(tensors) == 0:
        raise ValueError("Empty tensor list in pad_and_mask.")

    B = len(tensors)
    d = tensors[0].size(1)
    Lmax = max(t.size(0) for t in tensors)

    device = tensors[0].device
    out = torch.zeros(B, Lmax, d, device=device)
    mask = torch.zeros(B, Lmax, device=device, dtype=torch.bool)
    for i, t in enumerate(tensors):
        L = t.size(0)
        out[i, :L] = t
        mask[i, :L] = True
    return out, mask  # [B,L,d], [B,L]


class SublayerConnection(nn.Module):
    def __init__(self, dropout: float):
        super().__init__()
        self.dropout = nn.Dropout(dropout)

    def forward(self, original: torch.Tensor, attention: torch.Tensor):
        return original + self.dropout(attention)


class MultiBondAttention(nn.Module):
    def __init__(self, args: TrainArgs):
        super().__init__()
        self.hidden_size = args.hidden_size
        self.num_heads = args.num_heads
        att_size = self.hidden_size // self.num_heads
        self.scale = att_size ** -0.5

        self.W_q = nn.Linear(self.hidden_size, self.num_heads * att_size, bias=False)
        self.W_k = nn.Linear(self.hidden_size, self.num_heads * att_size, bias=False)
        self.W_v = nn.Linear(self.hidden_size, self.num_heads * att_size, bias=False)
        self.W_o = nn.Linear(self.num_heads * att_size, self.hidden_size)
        self.norm = nn.LayerNorm(self.hidden_size)

    def forward(self, message: torch.Tensor, b_scope: List[Tuple[int, int]]) -> torch.Tensor:
        outs = []
        for i, (b_start, b_size) in enumerate(b_scope):
            if b_size == 0:
                outs.append(torch.zeros(1, self.hidden_size, device=message.device).squeeze(0))
                continue
            cur = message.narrow(0, b_start, b_size)  # [Nb, H]
            B = cur.size(0)
            H = self.hidden_size
            h = self.num_heads
            d = H // h

            q = self.W_q(cur).view(B, h, d).transpose(0, 1)       # [h,Nb,d]
            k = self.W_k(cur).view(B, h, d).transpose(0, 1)       # [h,Nb,d]
            v = self.W_v(cur).view(B, h, d).transpose(0, 1)       # [h,Nb,d]

            att = torch.matmul(q, k.transpose(1, 2)) * self.scale  # [h,Nb,Nb]
            att = F.softmax(att, dim=-1)
            out = torch.matmul(att, v)                              # [h,Nb,d]
            out = out.transpose(0, 1).contiguous().view(B, H)       # [Nb,H]
            out = self.W_o(out)
            outs.append(out)
        return torch.cat(outs, dim=0)


class MPNEncoder(nn.Module):

    def __init__(self, args: TrainArgs, atom_fdim: int, bond_fdim: int):
        super().__init__()
        self.args = args
        self.atom_fdim = atom_fdim
        self.bond_fdim = bond_fdim
        self.atom_messages = args.atom_messages
        self.hidden_size = args.hidden_size
        self.bias = args.bias
        self.depth = args.depth
        self.dropout = args.dropout

        self.layers_per_message = 1
        self.undirected = args.undirected
        self.device_ = args.device
        self.aggregation = args.aggregation
        self.aggregation_norm = args.aggregation_norm

        self.bond_attention = args.bond_attention
        self.num_heads = args.num_heads

        self.dropout_layer = nn.Dropout(p=self.dropout)
        self.act_func = get_activation_function(args.activation)

        self.cached_zero_vector = nn.Parameter(torch.zeros(self.hidden_size), requires_grad=False)

        input_dim = self.atom_fdim if self.atom_messages else self.bond_fdim
        self.W_i = nn.Linear(input_dim, self.hidden_size, bias=self.bias)

        if self.atom_messages:
            w_h_input_size = self.hidden_size + self.bond_fdim
        else:
            w_h_input_size = self.hidden_size

        self.W_h = nn.Linear(w_h_input_size, self.hidden_size, bias=self.bias)
        self.W_o = nn.Linear(self.atom_fdim + self.hidden_size, self.hidden_size)

        if self.bond_attention:
            self.bond_attention_block = MultiBondAttention(args)
            self.bond_residual = SublayerConnection(dropout=self.dropout)

    def forward(self,
                mol_graph: BatchMolGraph,
                mol_adj_batch: Optional[List[np.ndarray]] = None,
                mol_dist_batch: Optional[List[np.ndarray]] = None,
                mol_clb_batch: Optional[List[np.ndarray]] = None) -> Tuple[List[torch.Tensor], torch.Tensor]:
        f_atoms, f_bonds, a2b, b2a, b2revb, a_scope, b_scope = mol_graph.get_components(
            atom_messages=self.atom_messages
        )
        f_atoms, f_bonds, a2b, b2a, b2revb = f_atoms.to(self.device_), f_bonds.to(self.device_), \
                                             a2b.to(self.device_), b2a.to(self.device_), b2revb.to(self.device_)

        if self.atom_messages:
            a2a = mol_graph.get_a2a().to(self.device_)

        if self.atom_messages:
            message = self.act_func(self.W_i(f_atoms))
        else:
            message = self.act_func(self.W_i(f_bonds))


        for _ in range(self.depth - 1):
            if self.undirected:
                message = (message + message[b2revb]) / 2

            if self.atom_messages:
                nei_a_message = index_select_ND(message, a2a)
                nei_f_bonds = index_select_ND(f_bonds, a2b)
                nei_message = torch.cat((nei_a_message, nei_f_bonds), dim=2)
                message = nei_message.sum(dim=1)
            else:
                nei_a_message = index_select_ND(message, a2b)
                a_message = nei_a_message.sum(dim=1)
                rev_message = message[b2revb]
                message = a_message[b2a] - rev_message
                if self.bond_attention:
                    att_message = self.bond_attention_block(message, b_scope)
                    message = self.bond_residual(message, att_message)

            message = self.W_h(message)
            message = self.act_func(message)
            message = self.dropout_layer(message)


        a2x = a2a if self.atom_messages else a2b
        nei_a_message = index_select_ND(message, a2x)
        a_message = nei_a_message.sum(dim=1)
        a_input = torch.cat([f_atoms, a_message], dim=1)
        atom_hiddens_all = self.act_func(self.W_o(a_input))
        atom_hiddens_all = self.dropout_layer(atom_hiddens_all)


        atom_hiddens_list: List[torch.Tensor] = []
        mol_vecs: List[torch.Tensor] = []
        for i, (a_start, a_size) in enumerate(a_scope):
            if a_size == 0:
                atom_hiddens_list.append(self.cached_zero_vector.unsqueeze(0))  # [1,H]
                mol_vecs.append(self.cached_zero_vector)
            else:
                cur = atom_hiddens_all.narrow(0, a_start, a_size)  # [Na,H]
                atom_hiddens_list.append(cur)
                if self.aggregation == 'mean':
                    mv = cur.mean(dim=0)
                elif self.aggregation == 'sum':
                    mv = cur.sum(dim=0)
                elif self.aggregation == 'norm':
                    mv = cur.sum(dim=0) / self.aggregation_norm
                else:
                    mv = cur.mean(dim=0)
                mol_vecs.append(mv)

        return atom_hiddens_list, torch.stack(mol_vecs, dim=0)  # List[Na,H], [B,H]



class PocketEncoder(nn.Module):


    def __init__(self, hidden_size: int, node_in_dim: int = 1, dropout: float = 0.1):
        super().__init__()
        self.hidden = hidden_size
        self.dropout = nn.Dropout(dropout)
        self.lin1 = nn.Linear(node_in_dim, hidden_size)
        self.lin2 = nn.Linear(hidden_size, hidden_size)

    @staticmethod
    def _nx_to_mats(g) -> Tuple[np.ndarray, np.ndarray]:
        if nx is None:
            raise RuntimeError("networkx is required to encode pocket graphs.")
        A = nx.to_numpy_array(g)
        N = A.shape[0]
        # node features
        X = None
        try:
            feats = []
            for _, data in g.nodes(data=True):
                if 'x' in data:
                    x = np.asarray(data['x'], dtype=np.float32).reshape(-1)
                else:
                    x = np.array([0.0], dtype=np.float32)
                feats.append(x)
            maxF = max(len(v) for v in feats) if feats else 1
            X = np.zeros((N, maxF), dtype=np.float32)
            for i, v in enumerate(feats):
                X[i, :len(v)] = v
        except Exception:
            X = None

        if X is None:
            deg = np.asarray([d for _, d in g.degree()], dtype=np.float32).reshape(-1, 1)
            X = deg
        return A.astype(np.float32), X.astype(np.float32)

    @staticmethod
    def _norm_adj(A: torch.Tensor) -> torch.Tensor:
        # A_hat = D^{-1/2} (A + I) D^{-1/2}
        N = A.size(0)
        A_hat = A + torch.eye(N, device=A.device)
        deg = A_hat.sum(dim=1)
        D_inv_sqrt = torch.diag(torch.pow(deg, -0.5).clamp(min=1e-6))
        return D_inv_sqrt @ A_hat @ D_inv_sqrt

    def _encode_one(self, pkt: Any, device: torch.device) -> torch.Tensor:

        if nx is not None and isinstance(pkt, nx.Graph):
            A_np, X_np = self._nx_to_mats(pkt)
        elif isinstance(pkt, dict) and ('adj' in pkt or 'A' in pkt):
            A_np = pkt.get('adj', pkt.get('A'))
            X_np = pkt.get('x', pkt.get('X', None))
            if X_np is None:
                # fallback: degree
                deg = (A_np > 0).astype(np.float32).sum(axis=1, keepdims=True)
                X_np = deg
        else:
            # 尝试当作 (adj, x) 二元组
            try:
                A_np, X_np = pkt
            except Exception:
                raise ValueError("Unrecognized pocket graph format.")

        A = torch.from_numpy(np.asarray(A_np)).to(device).float()       # [N,N]
        X = torch.from_numpy(np.asarray(X_np)).to(device).float()       # [N,F]
        A_hat = self._norm_adj(A)                                       # [N,N]

        H = A_hat @ self.lin1(X)                                        # [N,H]
        H = F.relu(H)
        H = self.dropout(H)
        H = A_hat @ self.lin2(H)                                        # [N,H]
        H = F.relu(H)
        return H  # [N,H]

    def forward(self, pockets: List[Any], device: torch.device) -> Tuple[List[torch.Tensor], torch.Tensor]:

        node_h_list: List[torch.Tensor] = []
        pooled_list: List[torch.Tensor] = []
        for pkt in pockets:
            H = self._encode_one(pkt, device=device)  # [Np,H]
            node_h_list.append(H)
            pooled_list.append(H.mean(dim=0) if H.size(0) > 0 else torch.zeros(self.hidden, device=device))
        return node_h_list, torch.stack(pooled_list, dim=0)  # List[Np,H], [B,H]


class CrossAttention(nn.Module):


    def __init__(self, hidden: int, num_heads: int = 4, dropout: float = 0.1):
        super().__init__()
        self.hidden = hidden
        self.h = num_heads
        self.d = hidden // num_heads
        self.Wq = nn.Linear(hidden, hidden, bias=False)
        self.Wk = nn.Linear(hidden, hidden, bias=False)
        self.Wv = nn.Linear(hidden, hidden, bias=False)
        self.out = nn.Linear(hidden, hidden)
        self.dropout = nn.Dropout(dropout)
        self.scale = self.d ** -0.5

    def forward(self,
                L: torch.Tensor, L_mask: torch.Tensor,
                P: torch.Tensor, P_mask: torch.Tensor) -> torch.Tensor:
        """
        L: [B, L, H], L_mask: [B, L]
        P: [B, P, H], P_mask: [B, P]
        return: pooled context [B, H]
        """
        B, Llen, H = L.shape
        _, Plen, _ = P.shape

        Q = self.Wq(L).view(B, Llen, self.h, self.d).transpose(1, 2)  # [B,h,L,d]
        K = self.Wk(P).view(B, Plen, self.h, self.d).transpose(1, 2)  # [B,h,P,d]
        V = self.Wv(P).view(B, Plen, self.h, self.d).transpose(1, 2)  # [B,h,P,d]

        att = torch.matmul(Q, K.transpose(-1, -2)) * self.scale  # [B,h,L,P]

        P_mask_ = P_mask.unsqueeze(1).unsqueeze(2)  # [B,1,1,P]
        att = att.masked_fill(~P_mask_, float('-inf'))
        att = F.softmax(att, dim=-1)
        att = self.dropout(att)

        C = torch.matmul(att, V)  # [B,h,L,d]
        C = C.transpose(1, 2).contiguous().view(B, Llen, H)  # [B,L,H]
        C = self.out(C)  # [B,L,H]

        L_mask_f = L_mask.float().unsqueeze(-1)  # [B,L,1]
        C = C * L_mask_f
        denom = L_mask_f.sum(dim=1).clamp(min=1e-6)  # [B,1]
        pooled = C.sum(dim=1) / denom  # [B,H]
        return pooled  # [B,H]



class MPN(nn.Module):
    def __init__(self,
                 args: TrainArgs,
                 atom_fdim: int = None,
                 bond_fdim: int = None):
        super().__init__()
        self.args = args
        self.device_ = args.device
        self.atom_fdim = atom_fdim or get_atom_fdim(overwrite_default_atom=args.overwrite_default_atom_features)
        self.bond_fdim = bond_fdim or get_bond_fdim(overwrite_default_atom=args.overwrite_default_atom_features,
                                                    overwrite_default_bond=args.overwrite_default_bond_features,
                                                    atom_messages=args.atom_messages)

        self.features_only = args.features_only
        self.use_input_features = args.use_input_features


        if args.mpn_shared:
            self.encoder = nn.ModuleList([MPNEncoder(args, self.atom_fdim, self.bond_fdim)] * args.number_of_molecules)
        else:
            self.encoder = nn.ModuleList([MPNEncoder(args, self.atom_fdim, self.bond_fdim)
                                          for _ in range(args.number_of_molecules)])

        self.pocket_encoder = PocketEncoder(hidden_size=args.hidden_size,
                                            node_in_dim=1,
                                            dropout=args.dropout)

        self.cross_attn = CrossAttention(hidden=args.hidden_size,
                                         num_heads=max(1, getattr(args, "num_heads", 4)),
                                         dropout=args.dropout)

    def forward(self,
                batch: Union[List[List[str]], List[List[Chem.Mol]], List[BatchMolGraph]],
                features_batch: Optional[List[np.ndarray]] = None,
                mol_adj_batch: Optional[List[np.ndarray]] = None,
                mol_dist_batch: Optional[List[np.ndarray]] = None,
                mol_clb_batch: Optional[List[np.ndarray]] = None,
                mol_seq_batch: Optional[List[np.ndarray]] = None,
                mol_sml_batch: Optional[List[np.ndarray]] = None,
                mol_pkt_batch: Optional[List[Any]] = None) -> torch.Tensor:


        atom_h_list, ligand_pooled = self.encoder[0](batch[0],
                                                     mol_adj_batch,
                                                     mol_dist_batch,
                                                     mol_clb_batch)
        lig_pad, lig_mask = pad_and_mask(atom_h_list)  # [B,L,H], [B,L]

        if mol_pkt_batch is None:
            B = ligand_pooled.size(0)
            cross_pool = torch.zeros_like(ligand_pooled)
            fused = torch.cat([ligand_pooled, cross_pool], dim=1)  # [B,2H]
        else:
            pk_node_list, pk_pooled = self.pocket_encoder(mol_pkt_batch, device=lig_pad.device)
            pk_pad, pk_mask = pad_and_mask(pk_node_list)  # [B,P,H], [B,P]

            cross_pool = self.cross_attn(lig_pad, lig_mask, pk_pad, pk_mask)  # [B,H]

            fused = torch.cat([ligand_pooled, cross_pool], dim=1)  # [B,2H]

        if self.use_input_features and features_batch is not None:
            feats = torch.from_numpy(np.stack(features_batch)).float().to(fused.device)
            if feats.dim() == 1:
                feats = feats.view(1, -1)
            fused = torch.cat([fused, feats], dim=1)

        return fused
