# -- coding: utf-8 --
from typing import List, Union, Optional
import numpy as np
import torch
import torch.nn as nn
from rdkit import Chem

from chemprop.args import TrainArgs
from chemprop.features import BatchMolGraph
from chemprop.nn_utils import get_activation_function, initialize_weights

from .mpn import MPN


class MoleculeModel(nn.Module):

    def __init__(self, args: TrainArgs, featurizer: bool = False):
        super().__init__()
        self.classification = args.dataset_type == 'classification'
        self.multiclass = args.dataset_type == 'multiclass'
        self.featurizer = featurizer

        self.output_size = args.num_tasks
        if self.multiclass:
            self.output_size *= args.multiclass_num_classes

        if self.classification:
            self.sigmoid = nn.Sigmoid()
        if self.multiclass:
            self.multiclass_softmax = nn.Softmax(dim=2)

        self.encoder = MPN(args)

        self._build_ffn(args)

        initialize_weights(self)

    def _build_ffn(self, args: TrainArgs) -> None:
        fused_dim = args.hidden_size * 2
        if args.use_input_features and args.features_size is not None:
            fused_dim += args.features_size

        dropout = nn.Dropout(args.dropout)
        activation = get_activation_function(args.activation)

        if args.ffn_num_layers == 1:
            layers = [dropout, nn.Linear(fused_dim, self.output_size)]
        else:
            hidden = args.ffn_hidden_size
            layers = [dropout, nn.Linear(fused_dim, hidden)]
            for _ in range(args.ffn_num_layers - 2):
                layers += [activation, dropout, nn.Linear(hidden, hidden)]
            layers += [activation, dropout, nn.Linear(hidden, self.output_size)]

        self.ffn = nn.Sequential(*layers)

    def featurize(self,
                  batch: Union[List[str], List[Chem.Mol], BatchMolGraph],
                  features_batch=None,
                  mol_adj_batch=None,
                  mol_dist_batch=None,
                  mol_clb_batch=None,
                  mol_seq_batch=None,
                  mol_sml_batch=None,
                  mol_pkt_batch=None) -> torch.FloatTensor:

        fused = self.encoder(batch,
                             features_batch,
                             mol_adj_batch,
                             mol_dist_batch,
                             mol_clb_batch,
                             mol_seq_batch,
                             mol_sml_batch,
                             mol_pkt_batch)
        return fused

    def forward(self,
                batch: Union[List[str], List[Chem.Mol], BatchMolGraph],
                features_batch: Optional[List[np.ndarray]] = None,
                mol_adj_batch: Optional[List[np.ndarray]] = None,
                mol_dist_batch: Optional[List[np.ndarray]] = None,
                mol_clb_batch: Optional[List[np.ndarray]] = None,
                mol_seq_batch: Optional[List[np.ndarray]] = None,
                mol_sml_batch: Optional[List[np.ndarray]] = None,
                mol_pkt_batch: Optional[List] = None) -> torch.FloatTensor:

        fused = self.encoder(batch,
                             features_batch,
                             mol_adj_batch,
                             mol_dist_batch,
                             mol_clb_batch,
                             mol_seq_batch,
                             mol_sml_batch,
                             mol_pkt_batch)
        out = self.ffn(fused)

        if self.classification and not self.training:
            out = self.sigmoid(out)
        if self.multiclass:
            out = out.view(out.size(0), -1, self.num_classes)
            if not self.training:
                out = self.multiclass_softmax(out)
        return out
