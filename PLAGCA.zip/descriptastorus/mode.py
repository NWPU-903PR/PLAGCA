class Mode:
    READONLY = 0
    WRITE = 1
    APPEND = 2
    READONCE = 3 # read through the file once...
